package com.info.movieinfoservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.info.movieinfoservice.model.Movie;
import com.info.movieinfoservice.repository.MovieRepository;

@RestController
public class MovieInfoResource {
	
	@Autowired
	MovieRepository movieRepo;
	
	@GetMapping("/movies/{movieId}")
	public Movie getMovieInfo(@PathVariable("movieId") int movieId){
			
			Movie movie = movieRepo.findMovieByMovieId(movieId);
			return movie;
		
	
	}
	
}
