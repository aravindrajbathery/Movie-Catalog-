package com.info.movieinfoservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.info.movieinfoservice.model.Movie;

public interface MovieRepository extends JpaRepository<Movie, Integer> {

	@Query(value = "SELECT * FROM movie m WHERE m.movie_id = ?1", nativeQuery = true)
	Movie findMovieByMovieId(Integer movieId);
}
