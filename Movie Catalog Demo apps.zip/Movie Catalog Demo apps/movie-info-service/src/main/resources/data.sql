insert into movie(id,movie_id,movie_name,desc) values(1,11,'fight club','Thriller movie');
insert into movie(id,movie_id,movie_name,desc) values(2,55,'avatar','Science Fiction');
insert into movie(id,movie_id,movie_name,desc) values(3,12,'Thor','Super Hero movie');
insert into movie(id,movie_id,movie_name,desc) values(4,14,'Iorn Man','Super Hero movie');
insert into movie(id,movie_id,movie_name,desc) values(5,33,'Inception','Science Fiction');
insert into movie(id,movie_id,movie_name,desc) values(6,77,'John Wick','Action movie');