package com.rating.ratingsdataservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.rating.ratingsdataservice.model.Rating;
import com.rating.ratingsdataservice.repositories.RatingRepository;

@RestController
public class RatingResource {
		
		@Autowired
		RatingRepository ratingRepo;
		
		@GetMapping("/rating/{userId}")
		public List<Rating> getRating(@PathVariable("userId") int userId) {
			return ratingRepo.findRatingByUserId(userId);
		}
}
