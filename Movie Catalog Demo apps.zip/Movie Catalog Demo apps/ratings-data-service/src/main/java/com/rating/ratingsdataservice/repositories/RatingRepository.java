package com.rating.ratingsdataservice.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.rating.ratingsdataservice.model.Rating;

public interface RatingRepository extends JpaRepository<Rating, Integer>{
	
	@Query(value = "SELECT * FROM rating r WHERE r.user_id = ?1", nativeQuery = true)
			List<Rating> findRatingByUserId(Integer userId);
	
}
