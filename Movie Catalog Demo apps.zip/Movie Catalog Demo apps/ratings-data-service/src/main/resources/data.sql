insert into rating(rating_id,user_id,movie_id,rating) values(1,333,77,'5.6');
insert into rating (rating_id,user_id,movie_id,rating) values(2,111,11,'9.0');
insert into rating (rating_id,user_id,movie_id,rating) values(3,111,55,'7.0');
insert into rating (rating_id,user_id,movie_id,rating) values(4,222,11,'9.0');
insert into rating (rating_id,user_id,movie_id,rating) values(5,222,33,'8.0');

