package com.catalog.moviecatalogservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.catalog.moviecatalogservice.model.Rating;

@Service
public class RatingInfoService {
	
	@Autowired
	private RestTemplate resttemplate;
	
	public ResponseEntity<Rating[]> getRatingInfo(String userId){
		return resttemplate.getForEntity("http://rating-service/rating/" +userId,
				Rating[].class);
	}

}
