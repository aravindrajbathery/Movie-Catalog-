package com.catalog.moviecatalogservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.catalog.moviecatalogservice.model.Movie;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class MovieInfoService {
	
	@Autowired
	private RestTemplate resttemplate;
	
	@HystrixCommand(fallbackMethod = "getFallbackMovieInfo")
	public Movie getMovieInfo(int MovieId) {
		return resttemplate.getForObject("http://movie-info-service/movies/" +MovieId,Movie.class);
	}
	
	
	public Movie getFallbackMovieInfo(int MovieId){
		return (new Movie(0, 0, "No Movie Found", " "));
	}

}
