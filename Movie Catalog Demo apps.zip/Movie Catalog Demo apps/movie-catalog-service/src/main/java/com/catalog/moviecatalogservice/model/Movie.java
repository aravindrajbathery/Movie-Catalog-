package com.catalog.moviecatalogservice.model;

public class Movie {

	private int id;
	private int movieId;
	private String movieName;
	private String desc;

	public Movie() {
		
	}
	public Movie(int id, int movieId, String movieName, String desc) {
		super();
		this.id = id;
		this.movieId = movieId;
		this.movieName = movieName;
		this.desc = desc;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
