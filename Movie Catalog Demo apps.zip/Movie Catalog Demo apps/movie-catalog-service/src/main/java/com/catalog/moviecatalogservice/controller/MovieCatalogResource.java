package com.catalog.moviecatalogservice.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.catalog.moviecatalogservice.model.CatalogItems;
import com.catalog.moviecatalogservice.model.Movie;
import com.catalog.moviecatalogservice.model.Rating;
import com.catalog.moviecatalogservice.service.MovieInfoService;
import com.catalog.moviecatalogservice.service.RatingInfoService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class MovieCatalogResource {
	@Autowired
	private RestTemplate resttemplate;
	
	
	@Autowired
	MovieInfoService movieInfo;
	
	@Autowired
	RatingInfoService ratingInfo;

	
	@GetMapping("/catalog/{userId}")
	public List<CatalogItems> getCatalog(@PathVariable("userId") String userId) {
		List<CatalogItems> catlogList = new ArrayList<CatalogItems>();
//		ResponseEntity<Rating[]> response = resttemplate.getForEntity("http://rating-service/rating/" +userId,
//				Rating[].class);
		ResponseEntity<Rating[]> response = ratingInfo.getRatingInfo(userId);
		Rating[] ratingsList = response.getBody();
		for (Rating rating : ratingsList) {
//			Movie movie = resttemplate.getForObject("http://movie-info-service/movies/" +rating.getMovieId(),
//					Movie.class);
			Movie movie = movieInfo.getMovieInfo(rating.getMovieId());
			catlogList.add(new CatalogItems(movie.getMovieName(), movie.getDesc(), rating.getRating()));
		}

		return catlogList;

	}
	
	
//	public List<CatalogItems> getFallbackCatalog(@PathVariable("userId") String userId) {
//			return Arrays.asList(new CatalogItems("No Movie", "", "0"));
//	}
	
	
	
	
	

}
